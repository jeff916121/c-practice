#include "Bag.h"

Bag::Bag()
{
}


Bag::~Bag()
{
	
}

Bag::Bag(int size)
	:size{size}
{

}


